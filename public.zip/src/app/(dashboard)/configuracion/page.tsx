import ConfiguracionView from "@/features/configuracion/ConfiguracionView"
export default function Page() {
  return <ConfiguracionView />
}
