import PersonalView from "@/features/personal/PersonalView"
export default function Page() {
  return <PersonalView />
}
