import CamarasFrigorificasView from "@/features/maquinaria/CamarasFrigorificasView"

export default function Page() {
  return <CamarasFrigorificasView />
}
