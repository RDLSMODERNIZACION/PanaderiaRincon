import HornosView from "@/features/maquinaria/HornosView"

export default function Page() {
  return <HornosView />
}
