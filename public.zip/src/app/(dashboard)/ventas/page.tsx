import VentasView from "@/features/ventas/VentasView"
export default function Page() {
  return <VentasView />
}
