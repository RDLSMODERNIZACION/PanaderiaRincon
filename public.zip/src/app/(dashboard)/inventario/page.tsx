import InventarioView from "@/features/inventario/InventarioView"
export default function Page() {
  return <InventarioView />
}
