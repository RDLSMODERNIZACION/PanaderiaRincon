import DashboardView from "@/features/dashboard/DashboardView"

export default function Page() {
  return <DashboardView />
}
