import ProductosView from "@/features/productos/ProductosView"
export default function Page() {
  return <ProductosView />
}
