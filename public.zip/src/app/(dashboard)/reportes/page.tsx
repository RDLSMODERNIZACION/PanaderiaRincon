import ReportesView from "@/features/reportes/ReportesView"
export default function Page() {
  return <ReportesView />
}
