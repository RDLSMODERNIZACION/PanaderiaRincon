import ProduccionView from "@/features/produccion/ProduccionView"
export default function Page() {
  return <ProduccionView />
}
