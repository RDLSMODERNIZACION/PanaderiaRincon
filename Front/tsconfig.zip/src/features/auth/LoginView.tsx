"use client"

import Image from "next/image"
import { useRouter, useSearchParams } from "next/navigation"
import { useState } from "react"
import { KeyRound, LogIn, Server, UserRound } from "lucide-react"
import Button from "@/components/ui/Button"
import Input from "@/components/ui/Input"
import { Card, CardBody } from "@/components/ui/Card"
import { getDefaultApiBaseUrl, useAuth } from "@/features/auth/AuthProvider"

export default function LoginView() {
  const router = useRouter()
  const search = useSearchParams()
  const next = search.get("next") || "/"
  const { login } = useAuth()
  const [apiBaseUrl, setApiBaseUrl] = useState(getDefaultApiBaseUrl())
  const [apiKey, setApiKey] = useState(process.env.NEXT_PUBLIC_DEFAULT_API_KEY || "")
  const [userId, setUserId] = useState("")
  const [mode, setMode] = useState<"api_key" | "user">("api_key")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    setLoading(true)
    setError(null)
    try {
      await login({
        apiBaseUrl,
        apiKey: apiKey || undefined,
        userId: mode === "user" ? userId || undefined : undefined
      })
      router.replace(next)
    } catch (exc: any) {
      setError(exc?.message || "No se pudo iniciar sesión")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="grid min-h-screen place-items-center bg-zinc-50 px-4 py-10">
      <div className="w-full max-w-md space-y-5">
        <div className="text-center">
          <div className="mx-auto grid h-20 w-20 place-items-center overflow-hidden rounded-full bg-black">
            <Image src="/brand/logo-panaderia-rincon.png.jpeg" alt="Panadería Rincón" width={80} height={80} className="h-20 w-20 object-contain" priority />
          </div>
          <h1 className="mt-4 text-2xl font-semibold tracking-tight">Panadería Rincón</h1>
          <p className="mt-1 text-sm text-zinc-600">Frontend conectado al backend FastAPI + Supabase.</p>
        </div>

        <Card>
          <CardBody className="space-y-4">
            <div>
              <label className="mb-1 block text-xs font-medium text-zinc-600">Backend URL</label>
              <div className="relative">
                <Server className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                <Input value={apiBaseUrl} onChange={e => setApiBaseUrl(e.target.value)} className="pl-9" placeholder="https://...onrender.com" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 rounded-2xl bg-zinc-100 p-1">
              <button type="button" className={`rounded-xl px-3 py-2 text-sm ${mode === "api_key" ? "bg-white shadow-sm" : "text-zinc-600"}`} onClick={() => setMode("api_key")}>API Key / Admin</button>
              <button type="button" className={`rounded-xl px-3 py-2 text-sm ${mode === "user" ? "bg-white shadow-sm" : "text-zinc-600"}`} onClick={() => setMode("user")}>Usuario</button>
            </div>

            <div>
              <label className="mb-1 block text-xs font-medium text-zinc-600">API Key {mode === "user" ? "opcional" : ""}</label>
              <div className="relative">
                <KeyRound className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                <Input value={apiKey} onChange={e => setApiKey(e.target.value)} className="pl-9" type="password" placeholder="X-API-Key si la configuraste en Render" />
              </div>
              <p className="mt-1 text-[11px] text-zinc-500">En modo prueba, si AUTH_REQUIRED=0 y API_KEY está vacío, el backend entra como desarrollo.</p>
            </div>

            {mode === "user" ? (
              <div>
                <label className="mb-1 block text-xs font-medium text-zinc-600">User ID</label>
                <div className="relative">
                  <UserRound className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                  <Input value={userId} onChange={e => setUserId(e.target.value)} className="pl-9" placeholder="usr_xxxxx" />
                </div>
                <p className="mt-1 text-[11px] text-zinc-500">Los usuarios se administran en Seguridad → Usuarios.</p>
              </div>
            ) : null}

            {error ? <div className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div> : null}

            <Button className="w-full" onClick={submit} disabled={loading || !apiBaseUrl}>
              <LogIn className="mr-2 h-4 w-4" /> {loading ? "Conectando…" : "Entrar"}
            </Button>
          </CardBody>
        </Card>

        <p className="text-center text-xs text-zinc-500">Sin datos hardcodeados: todo se lee y escribe contra el backend.</p>
      </div>
    </div>
  )
}
